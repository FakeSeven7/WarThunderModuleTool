bl_info = {
    "name": "模型修复工具",
    "blender": (4, 4, 0),
    "category": "Object",
    "description": "提供多个功能用于战争雷霆载具模型修复",
    "author": "FakeSeven",
    "version": (1, 1, 0),
    "location": "视图 3D > WTtool 面板",
    "warning": "",
}

import bpy
import bmesh
from bpy.props import BoolProperty, StringProperty
from bpy.types import Operator, Panel

class OBJECT_OT_main_menu(Operator):
    bl_idname = "object.main_menu"
    bl_label = "返回"
    bl_description = "返回上一级菜单"
    def execute(self, context):
        context.scene.show_secondary_panel = False
        return {'FINISHED'}

class OBJECT_OT_air_vehicle(Operator):
    bl_idname = "object.air_vehicle"
    bl_label = "空中载具"
    bl_description = "用于处理空中载具的模型"
    def execute(self, context):
        def draw_func(self, context):
            self.layout.label(text="请注意，执行清空场景后请将模型以“按组拆分”的形式导入新建的工程组中")
        bpy.context.window_manager.popup_menu(draw_func, title="提示", icon='INFO')
        context.scene.vehicle_type = "air"
        context.scene.show_secondary_panel = True
        return {'FINISHED'}

class OBJECT_OT_ground_vehicle(Operator):
    bl_idname = "object.ground_vehicle"
    bl_label = "地面载具"
    bl_description = "用于处理地面载具的模型"
    def execute(self, context):
        def draw_func(self, context):
            self.layout.label(text="请注意，执行清空场景后请将模型以“按组拆分”的形式导入新建的工程组中")
        bpy.context.window_manager.popup_menu(draw_func, title="提示", icon='INFO')
        context.scene.vehicle_type = "ground"
        context.scene.show_secondary_panel = True
        return {'FINISHED'}

class OBJECT_OT_clear_scene(Operator):
    bl_idname = "object.clear_scene"
    bl_label = "清空场景"
    bl_description = "请注意！此操作会清空场景内所有项目并新建工程组"
    def execute(self, context):
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.delete()
        if "Collection" in bpy.data.collections:
            bpy.data.collections.remove(bpy.data.collections["Collection"])
        if "Aviation_Work" not in bpy.data.collections:
            geo_collection = bpy.data.collections.new("Aviation_Work")
            bpy.context.scene.collection.children.link(geo_collection)
        context.scene.enable_other_buttons = True
        return {'FINISHED'}

class OBJECT_OT_clean_low_res(Operator):
    bl_idname = "object.clean_low_res"
    bl_label = "清理杂项"
    bl_description = "此操作会清理组内所有不属于机身主体部分的部件，仅对工程组中的对象生效"

    def execute(self, context):
        if "Aviation_Work" in bpy.data.collections:
            geo_collection = bpy.data.collections["Aviation_Work"]
            objects_to_remove = []

            for obj in geo_collection.objects:
                if obj.type == 'MESH' and obj.data.materials:
                    delete_obj = True

                    for mat in obj.data.materials:
                        if mat and mat.node_tree:
                            for node in mat.node_tree.nodes:
                                if node.type == 'TEX_IMAGE' and node.image:
                                    image_res_x, image_res_y = node.image.size
                                    
                                    if image_res_x >= 2048 and image_res_y >= 2048:
                                        delete_obj = False
                                        break

                    if delete_obj:
                        objects_to_remove.append(obj)

            for obj in objects_to_remove:
                bpy.data.objects.remove(obj)

        return {'FINISHED'}

class OBJECT_OT_shift_uv(Operator):
    bl_idname = "object.shift_uv"
    bl_label = "移动UV"
    bl_description = "将UV向上移动一个单位，仅对工程组中的对象生效"
    def execute(self, context):
        if "Aviation_Work" in bpy.data.collections:
            geo_collection = bpy.data.collections["Aviation_Work"]
            for obj in geo_collection.objects:
                if obj.type == 'MESH' and obj.data.uv_layers:
                    for uv_layer in obj.data.uv_layers:
                        for loop in obj.data.loops:
                            uv_coord = obj.data.uv_layers.active.data[loop.index].uv
                            uv_coord.y += 1
        return {'FINISHED'}

class OBJECT_OT_assign_material(Operator):
    bl_idname = "object.assign_material"
    bl_label = "赋予材质"
    bl_description = "为多边形对象赋予材质，仅对工程组中的对象生效"
    def execute(self, context):
        if "Aviation_Work" in bpy.data.collections:
            geo_collection = bpy.data.collections["Aviation_Work"]
            if "Body" not in bpy.data.materials:
                body_material = bpy.data.materials.new(name="Body")
            else:
                body_material = bpy.data.materials["Body"]
            if "Add" not in bpy.data.materials:
                add_material = bpy.data.materials.new(name="Add")
            else:
                add_material = bpy.data.materials["Add"]
            for obj in geo_collection.objects:
                if obj.type == 'MESH' and obj.data.materials:
                    has_add_texture = False
                    for mat in obj.data.materials:
                        if mat and mat.node_tree:
                            for node in mat.node_tree.nodes:
                                if node.type == 'TEX_IMAGE' and node.image:
                                    if "_add_" in node.image.filepath:
                                        has_add_texture = True
                    obj.data.materials.clear()
                    obj.data.materials.append(add_material if has_add_texture else body_material)
        return {'FINISHED'}

class OBJECT_OT_delete_invalid_uv(Operator):
    bl_idname = "object.delete_invalid_uv"
    bl_label = "删除小块"
    bl_description = "移除可能存在的小方块，仅对工程组中的对象生效"
    def execute(self, context):
        if "Aviation_Work" in bpy.data.collections:
            geo_collection = bpy.data.collections["Aviation_Work"]
            for obj in geo_collection.objects:
                if obj.type == 'MESH' and obj.data.uv_layers:
                    me = obj.data
                    bm = bmesh.new()
                    bm.from_mesh(me)
                    uv_layer = bm.loops.layers.uv.active
                    if not uv_layer:
                        continue
                    faces_to_remove = []
                    uv_margin = 3 / 2048
                    for face in bm.faces:
                        for loop in face.loops:
                            uv_coord = loop[uv_layer].uv
                            if uv_coord.x < uv_margin or uv_coord.x > (1 - uv_margin) or uv_coord.y < uv_margin or uv_coord.y > (1 - uv_margin):
                                faces_to_remove.append(face)
                                break
                    bmesh.ops.delete(bm, geom=faces_to_remove, context='FACES')
                    bm.to_mesh(me)
                    bm.free()
        return {'FINISHED'}

class OBJECT_OT_ground_clear_scene(Operator):
    bl_idname = "object.ground_clear_scene"
    bl_label = "清空场景"
    bl_description = "请注意！此操作会清空场景内所有项目并新建工程组"
    def execute(self, context):
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.delete()
        if "Collection" in bpy.data.collections:
            bpy.data.collections.remove(bpy.data.collections["Collection"])
        if "Ground_Work" not in bpy.data.collections:
            geo_collection = bpy.data.collections.new("Ground_Work")
            bpy.context.scene.collection.children.link(geo_collection)
        context.scene.enable_other_buttons = True
        return {'FINISHED'}

class OBJECT_OT_ground_clean_low_res(Operator):
    bl_idname = "object.ground_clean_low_res"
    bl_label = "清理杂项"
    bl_description = "清理不需要的多边形对象，仅对工程组中的对象生效"
    def execute(self, context):
        if "Ground_Work" in bpy.data.collections:
            geo_collection = bpy.data.collections["Ground_Work"]
            total_mesh = 0
            objects_to_remove = []
            for obj in geo_collection.objects:
                if obj.type == 'MESH':
                    total_mesh += 1
                    delete_obj = False
                    if "_track" in obj.name.lower() or "_mg_" in obj.name.lower():
                        delete_obj = True
                    else:
                        if obj.data.materials:
                            for mat in obj.data.materials:
                                if mat and mat.node_tree:
                                    for node in mat.node_tree.nodes:
                                        if node.type == 'TEX_IMAGE' and node.image:
                                            filepath = node.image.filepath.lower()
                                            if not ("body" in filepath or "gun" in filepath or "turret" in filepath or "add" in filepath):
                                                delete_obj = True
                                                break
                                    if delete_obj:
                                        break
                    if delete_obj:
                        objects_to_remove.append(obj)
            if total_mesh > 0 and len(objects_to_remove) == total_mesh:
                self.report({'ERROR'}, "删除操作将删除所有对象，操作取消")
                return {'CANCELLED'}
            for obj in objects_to_remove:
                bpy.data.objects.remove(obj)
        return {'FINISHED'}

class OBJECT_OT_ground_assign_material(Operator):
    bl_idname = "object.ground_assign_material"
    bl_label = "赋予材质"
    bl_description = "为对象赋予材质，仅对工程组中的对象生效"
    def execute(self, context):
        if "Ground_Work" in bpy.data.collections:
            geo_collection = bpy.data.collections["Ground_Work"]
            for obj in geo_collection.objects:
                if obj.type == 'MESH' and obj.data.materials:
                    assign_mat = None
                    for mat in obj.data.materials:
                        if mat and mat.node_tree:
                            for node in mat.node_tree.nodes:
                                if node.type == 'TEX_IMAGE' and node.image:
                                    filepath = node.image.filepath.lower()
                                    if "gun" in filepath:
                                        if "Gun" not in bpy.data.materials:
                                            gun_material = bpy.data.materials.new(name="Gun")
                                        else:
                                            gun_material = bpy.data.materials["Gun"]
                                        gun_material.diffuse_color = (1, 1, 0, 1)
                                        assign_mat = gun_material
                                        break
                                    elif "body" in filepath:
                                        if "_add" in filepath:
                                            if "BodyAdd" not in bpy.data.materials:
                                                body_add = bpy.data.materials.new(name="BodyAdd")
                                            else:
                                                body_add = bpy.data.materials["BodyAdd"]
                                            body_add.diffuse_color = (0.5, 0.5, 1, 1)
                                            assign_mat = body_add
                                        else:
                                            if "Body" not in bpy.data.materials:
                                                body_material = bpy.data.materials.new(name="Body")
                                            else:
                                                body_material = bpy.data.materials["Body"]
                                            body_material.diffuse_color = (0, 0, 1, 1)
                                            assign_mat = body_material
                                        break
                                    elif "turret" in filepath:
                                        if "_add" in filepath:
                                            if "TurretAdd" not in bpy.data.materials:
                                                turret_add = bpy.data.materials.new(name="TurretAdd")
                                            else:
                                                turret_add = bpy.data.materials["TurretAdd"]
                                            turret_add.diffuse_color = (1, 0.5, 0.5, 1)
                                            assign_mat = turret_add
                                        else:
                                            if "Turret" not in bpy.data.materials:
                                                turret_material = bpy.data.materials.new(name="Turret")
                                            else:
                                                turret_material = bpy.data.materials["Turret"]
                                            turret_material.diffuse_color = (1, 0, 0, 1)
                                            assign_mat = turret_material
                                        break
                            if assign_mat is not None:
                                break
                    if assign_mat is not None:
                        obj.data.materials.clear()
                        obj.data.materials.append(assign_mat)
        return {'FINISHED'}

class OBJECT_OT_move_wheels(Operator):
    bl_idname = "object.move_wheels"
    bl_label = "移动轮组"
    bl_description = "将轮组和悬挂向下移动两个单位，仅对工程组中的内容生效"
    def execute(self, context):
        if "Ground_Work" in bpy.data.collections:
            geo_collection = bpy.data.collections["Ground_Work"]
            for obj in geo_collection.objects:
                if obj.type == 'MESH' and ("wheel" in obj.name.lower() or "suspension" in obj.name.lower()):
                    obj.location.z -= 2
            context.scene.wheels_moved = True
        return {'FINISHED'}

class OBJECT_OT_undo_move(Operator):
    bl_idname = "object.undo_move"
    bl_label = "撤销移动"
    bl_description = "撤销刚才的轮组移动"
    @classmethod
    def poll(cls, context):
        return getattr(context.scene, "wheels_moved", False)
    def execute(self, context):
        if "Ground_Work" in bpy.data.collections:
            geo_collection = bpy.data.collections["Ground_Work"]
            for obj in geo_collection.objects:
                if obj.type == 'MESH' and ("wheel" in obj.name.lower() or "suspension" in obj.name.lower()):
                    obj.location.z += 2
            context.scene.wheels_moved = False
        return {'FINISHED'}

class OBJECT_PT_main_panel(Panel):
    bl_label = "模型修复工具"
    bl_idname = "OBJECT_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "WTtool"
    def draw(self, context):
        layout = self.layout
        if not context.scene.show_secondary_panel:
            row = layout.row()
            row.operator("object.air_vehicle", text="空中载具")
            row.operator("object.ground_vehicle", text="地面载具")
        else:
            layout.operator("object.main_menu", text="返回")
            if context.scene.vehicle_type == "air":
                layout.operator("object.clear_scene", text="清空场景")
                layout.operator("object.clean_low_res", text="清理杂项")
                layout.operator("object.shift_uv", text="移动UV")
                layout.operator("object.assign_material", text="赋予材质")
                layout.operator("object.delete_invalid_uv", text="删除小块")
            elif context.scene.vehicle_type == "ground":
                layout.operator("object.ground_clear_scene", text="清空场景")
                layout.operator("object.ground_clean_low_res", text="清理杂项")
                layout.operator("object.shift_uv", text="移动UV")
                layout.operator("object.ground_assign_material", text="赋予材质")
                layout.operator("object.delete_invalid_uv", text="删除小块")
                row = layout.row(align=True)
                row.operator("object.move_wheels", text="移动轮组")
                row.operator("object.undo_move", text="撤销移动")

def register():
    bpy.utils.register_class(OBJECT_OT_main_menu)
    bpy.utils.register_class(OBJECT_OT_air_vehicle)
    bpy.utils.register_class(OBJECT_OT_ground_vehicle)
    bpy.utils.register_class(OBJECT_OT_clear_scene)
    bpy.utils.register_class(OBJECT_OT_clean_low_res)
    bpy.utils.register_class(OBJECT_OT_shift_uv)
    bpy.utils.register_class(OBJECT_OT_assign_material)
    bpy.utils.register_class(OBJECT_OT_delete_invalid_uv)
    bpy.utils.register_class(OBJECT_OT_ground_clear_scene)
    bpy.utils.register_class(OBJECT_OT_ground_clean_low_res)
    bpy.utils.register_class(OBJECT_OT_ground_assign_material)
    bpy.utils.register_class(OBJECT_OT_move_wheels)
    bpy.utils.register_class(OBJECT_OT_undo_move)
    bpy.utils.register_class(OBJECT_PT_main_panel)
    bpy.types.Scene.show_secondary_panel = BoolProperty(default=False)
    bpy.types.Scene.enable_other_buttons = BoolProperty(default=False)
    bpy.types.Scene.vehicle_type = StringProperty(default="air")
    bpy.types.Scene.wheels_moved = BoolProperty(default=False)

def unregister():
    bpy.utils.unregister_class(OBJECT_PT_main_panel)
    bpy.utils.unregister_class(OBJECT_OT_undo_move)
    bpy.utils.unregister_class(OBJECT_OT_move_wheels)
    bpy.utils.unregister_class(OBJECT_OT_ground_assign_material)
    bpy.utils.unregister_class(OBJECT_OT_ground_clean_low_res)
    bpy.utils.unregister_class(OBJECT_OT_ground_clear_scene)
    bpy.utils.unregister_class(OBJECT_OT_delete_invalid_uv)
    bpy.utils.unregister_class(OBJECT_OT_assign_material)
    bpy.utils.unregister_class(OBJECT_OT_shift_uv)
    bpy.utils.unregister_class(OBJECT_OT_clean_low_res)
    bpy.utils.unregister_class(OBJECT_OT_clear_scene)
    bpy.utils.unregister_class(OBJECT_OT_ground_vehicle)
    bpy.utils.unregister_class(OBJECT_OT_air_vehicle)
    bpy.utils.unregister_class(OBJECT_OT_main_menu)
    del bpy.types.Scene.show_secondary_panel
    del bpy.types.Scene.enable_other_buttons
    del bpy.types.Scene.vehicle_type
    del bpy.types.Scene.wheels_moved

if __name__ == "__main__":
    register()
